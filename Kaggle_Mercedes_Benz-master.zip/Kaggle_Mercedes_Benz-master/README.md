# Kaggle Mercedes-Benz Greener Manufacturing
Kaggle Competition: [Mercedes-Benz Greener Manufacturing](https://www.kaggle.com/c/mercedes-benz-greener-manufacturing)

## Contents

## License
This project is licensed under the terms of the MIT license.
