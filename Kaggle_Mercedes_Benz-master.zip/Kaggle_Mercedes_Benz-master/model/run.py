#!/usr/local/miniconda2/bin/python
# _*_ coding: utf-8 _*_

"""
@author: MarkLiu
@time  : 17-7-1 下午1:15
"""
from __future__ import absolute_import, division, print_function

import os
import sys

module_path = os.path.abspath(os.path.join('..'))
sys.path.append(module_path)

cmd = 'rm ../result/*.csv'
os.system(cmd)

cmd = 'python simple_xgboost_baseline.py'
os.system(cmd)
